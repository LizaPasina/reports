class SettingsApp:
    
    APP_WIDTH = 800
    APP_HEIGH = 600
    APP_TITLE = "FurnitureApp"

    # DB
    host = "127.0.0.1"
    database = "furniture_db"
    user = "root"
    password = "toor"